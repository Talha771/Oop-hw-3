#include "pigeon.hpp"
#include <iostream>
using namespace std;
// // please refer to egg::cpp, and then nest.cpp before looking at this code, they are both important
// to understand this. 
struct Coordinates
{
    int x,y,w,h;
};
int Pigeon::fly(int a)
    {
    if (a==7){
        return 1;
    }
    if  (a==0)
    {
        return 2;
    }
    else
    {
        return 0;
    }
}
bool flag=false;
void Pigeon::draw(SDL_Renderer* gRenderer, SDL_Texture* assets){
    SDL_RenderCopy(gRenderer, assets, &srcRect, &moverRect);
    struct Coordinates h[3];
    h[0] = {7, 15, 155, 102};
    h[1] = {0, 164, 153, 83};
    h[2] = {2, 288, 159, 123};
    int k=fly(srcRect.x);
        srcRect.x=h[k].x;
        srcRect.y=h[k].y;
        srcRect.w=h[k].w;
        srcRect.h=h[k].h;
    if (moverRect.x>=999)
    {
        flag=true;
    }
    if (moverRect.x<=0)
    {
        flag=false;
    }
    if (flag==false)
    {
        moverRect.x+=50;
    }
    if (flag==true)
    {
        moverRect.x-=50;
    } 
}

Pigeon::Pigeon()
{
    moverRect = {30, 40, 50, 60};
}
Pigeon::Pigeon(int x, int y){
    moverRect={x,y,50,60};
}