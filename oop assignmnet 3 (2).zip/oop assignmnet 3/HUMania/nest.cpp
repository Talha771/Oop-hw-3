#include "nest.hpp"
#include <iostream>
using namespace std;
// nest implementation will go here.
struct Coordinates{
    int x,y,w,h;
};
// coordinate struct to store asset coordintes from png.
// like egg::drop() function but alternates between 3 images constantly to create a better animation 
// NOTE: Read egg.cpp for clarity. 
int nest::wiggle(int a){
    if (a==484){
        return 1;
    }
    if  (a==489){
        return 2;
    }
    else{
        return 0;
    }
}
bool flag2=false;
// the main difference between this function is the flag variable, which decides the direction 
// to move the object is. Once the object reaches the left or right end of the frame, the orientation of the 
//  object is reversed and it starts travelling in the opposite direction. 
void nest::draw(SDL_Renderer* gRenderer, SDL_Texture* assets)
{
    SDL_RenderCopy(gRenderer, assets, &srcRect, &moverRect);
    struct Coordinates h[3];
    h[0] = {484, 0, 156, 145};
    h[1] = {489, 171, 41, 99};
    h[2] = {494, 308, 144, 107};
    int k=wiggle(srcRect.x);
        srcRect.x=h[k].x;
        srcRect.y=h[k].y;
        srcRect.w=h[k].w;
        srcRect.h=h[k].h;
    if (moverRect.x>=999)
    {
        flag2=true;
    }
    if (moverRect.x<=0)
    {
        flag2=false;
    }
    if (flag2==false)
    {
        moverRect.x+=30;
        }
    if (flag2==true){
        moverRect.x-=30;
    } // moves the nest one pixel towards right, should it be in fly function??
}

nest::nest()
{
    moverRect = {30, 40, 50, 60};
}
nest::nest(int x, int y)
{
    moverRect={x,y,50,60};
}