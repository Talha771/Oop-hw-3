#include "egg.hpp"
#include <iostream>
using namespace std;
// egg implementation will go here.
struct Coordinates{
    int x,y,w,h;
};
// Structure defined here to make it easier to store asset coordinates
int egg::drop (int a){
    struct Coordinates h[2];
    // h is an array containing coordinate values of assets. 
    h[0] = {228, 24, 132, 174};
    h[1] = {207, 244, 231, 186};
    // this function decides what to draw when, when the moverRect.y, shown as a here is less than 500, 
    // the egg stays solid, as soon as it reaches 500 or greater, it returns the element of the array to draw. 
    if (a < 500 ){
        return 0;
    }
    else if (a >=500){
        return 1;
    }
}

void egg::draw(SDL_Renderer* gRenderer, SDL_Texture* assets){
    SDL_RenderCopy(gRenderer, assets, &srcRect, &moverRect);
    struct Coordinates h[2];
    h[0] = {228, 24, 132, 174};
    h[1] = {207, 244, 231, 186};
    int k = drop(moverRect.y);
    // this function, calls the drop function to check which image to draw and also animtes 
    // the downward motion of the egg.  
    if (k==0){
        srcRect.x=h[k].x;
        srcRect.y=h[k].y;
        srcRect.w=h[k].w;
        srcRect.h=h[k].h;
        moverRect.y+=50;
        }
    // as soon as the y values which is passed as parameter becomes more than 500, it reaches the ground 
    // and then breaks. 
    else if (k==1){
        srcRect.x=h[k].x;
        srcRect.y=h[k].y;
        srcRect.w=h[k].w;
        srcRect.h=h[k].h;
    } 
}

egg::egg(){
    moverRect = {20, 30, 50, 60};
    // defintion of egg starting position for default object 
}
egg::egg(int x, int y){
    // overloaded constructor for mouse-click generated object. 
    moverRect={x,y,50,60};
}