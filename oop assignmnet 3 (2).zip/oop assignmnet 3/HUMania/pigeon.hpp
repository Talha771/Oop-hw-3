#include<SDL.h>
// refer to nest.hpp, the code is nearly identical. 
class Pigeon{
SDL_Rect srcRect, moverRect;

public:
    // add the fly function here as well.
    int fly(int a);
    void draw(SDL_Renderer*, SDL_Texture* assets);
    Pigeon();
    Pigeon(int x,int y); // may add other overloaded constructors here... 
};
