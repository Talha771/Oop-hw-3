#include<iostream>
#include "vector.cpp"
#include "HUMania.hpp"
// this file creates vectors by using a custom vector class, and then generates vectors for each class type

// every time the user clicks the mouse, the program takes the x and y coordinates of the mouse click
// // and randomly generates an object in its respective vector. 
// the  draww objcet function runs for loops through the vector to generate every possible 
// instance of the objects generated
MyVector<egg> e2;
MyVector <Pigeon> p2;
MyVector <nest> n2;
int i;
void HUMania::drawObjects(){    
    for (int i=0;i<e2.size();i++){
        e2[i].draw(gRenderer,assets);
    }
    for (int j=0;j<p2.size();j++){
        p2[j].draw(gRenderer,assets);
    }
    for (int k=0; k<n2.size();k++){
        n2[k].draw(gRenderer,assets);
    }
    p1.draw(gRenderer, assets);
    e1.draw(gRenderer,assets);
    n1.draw(gRenderer,assets);
}


void HUMania::createObject(int x, int y){
    std::cout<<y;
    int r=rand()%2+1;
    if (r==1){
        e2.push_back(egg(x,y));
    }
    if (r==2){
        p2.push_back(Pigeon(x,y));
    }
    if (r==3){
        n2.push_back(nest(x,y));

    }

}

HUMania::HUMania(SDL_Renderer *renderer, SDL_Texture *asst):gRenderer(renderer), assets(asst){}
