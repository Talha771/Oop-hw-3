#include<SDL.h>
// nest object class defined here, if you have read the egg code, then this is pretty 
//  much the same functions, apart from some movements, and animation, the mechanics are the same. s
class nest{
SDL_Rect srcRect, moverRect;

public:
    // add the fly function here as well.
    int wiggle(int a);
    void draw(SDL_Renderer*, SDL_Texture* assets);
    nest();
    nest(int x,int y); // may add other overloaded constructors here... 
};
