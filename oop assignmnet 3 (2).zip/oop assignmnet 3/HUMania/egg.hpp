#include<SDL.h>
// this file defines the egg class, the egg class has majorly two functions, the drop and the draw function.
// The draw function is the definitve function that creates an image on the screen and also
// animates the downward motion of the egg.  

// See egg.cpp for drop function and implementation. 
class egg{
SDL_Rect srcRect, moverRect;

public:
    int drop (int a);
    void draw(SDL_Renderer*, SDL_Texture* assets);
    egg(); 
    egg (int x,int y);// may add other overloaded constructors here... 
};
