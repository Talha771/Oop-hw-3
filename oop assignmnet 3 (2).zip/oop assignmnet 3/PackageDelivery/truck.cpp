#include "truck.hpp"

//the functions made here will be called in truckDelivery.cpp file
//object 1
//constructor
Truck::Truck(string d, string p, string m, string e, string f ): driver(d), petrol(stoi(p)),money(stoi(m)), emptyMileage(stoi(e)),fullMileage(stoi(f)){}
void Truck::load(int numBox){
    cout<<driver<<endl;
    //generating boxes
    for (int i=0; i<numBox; i++){
        box[i]=Box();
    }
}
void Truck::unload()
{
    int total_vol=0;
    for (int i=0; i<10;i++)
    {
      //calculating volume of boxes that are being unloaded
      total_vol += box[i].volume();  
    }
    cout<<"Total volume of all boxes carried by trucks: "<< total_vol<<endl;
    //sending new data into trip.txt file
    ofstream file;
    file.open("Trip.txt", std::ios_base::app); 

    file<< driver << endl;             
    file << petrol << endl;
    file << money  << endl;
    file << emptyMileage << endl;
    file << fullMileage <<endl;

    file.close();

}
//calculating if the journey can be made on whether they have enough money or no
bool Truck::calculating() 

{
    //to check how much fuel is required
    float check;  
    
    
    if (petrol<50)
    {
        check=50-petrol;

        if (money >= (check*2.73))
        {
            petrol+=check;
            //subtracting cost of fuel from money driver had
            money-=(check*2.73);  
        }
        else 
        {
            cout<<"Truck to be removed: "<<driver<<endl;
            return false;
        }
    }
    
    return true;
}
//this function checks how much fuel is left after the journey is completed
void Truck::updating()   
{
    int returnn;
    //subtracting mileage from total capacity (50)
    petrol=50-(60/fullMileage);  
    //fuel required to return
    returnn=60/emptyMileage;  

    if (petrol>=returnn)
    {
        //subtracting fuel used from petrol remaining
        petrol-=60/emptyMileage;  
    }

    //money has already been subtracted in the above calculating function
}
