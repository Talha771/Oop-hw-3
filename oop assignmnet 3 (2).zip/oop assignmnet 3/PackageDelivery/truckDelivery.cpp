#include <iostream>
#include "TruckDelivery.hpp"
#include <fstream>
#include <string>
using namespace std;
// vector<Truck> trucks;

void TruckDelivery::loadTrucks() //unreading the Drivers.txt and storing data in array called dataa 
{
    //initializing the array
    //truck has 5 attributes hence setting the size of array to five to store all of them
    string dataa[5];  
    //count keeps track of set of truck data 
    int count = 0;
    //file open
    //reading the Drivers.txt file
    std::ifstream file("Drivers.txt");  
    std::string data;  

    while (getline(file,data)) 
    {
        //data being stored in array 
        //index of the array = count   
        dataa[count]=data;  
        
        //one set of truck data is stored as the count becomes 4
        //0,1,2,3,4 --> 5 elements/attributes
        if (count == 4 ) 
       {
           //data being pushed into the vector trucks
           //constructor
           trucks.push_back(Truck(dataa[0],dataa[1],dataa[2],dataa[3],dataa[4]));  
            count=-1;
       }
       //as one set of data gets stored in the vector an increment in count takes place
       //next set of data obtained is then stored in array, overriding previous set
       count++;  
    }

    for (int i=0;i<trucks.size();i++)
    {
        trucks[i].load(10);
        
    }

}
//the calculating funtion in truck.cpp is being called here on each truck using a for loop
void TruckDelivery::calculateCost()  
{
    //this vector stores truck unable to afford the journey
    vector<int> n;
    for (int i=0;i<trucks.size();i++)
    {
        if (trucks[i].calculating() == false)
        {
            n.push_back(i);  
           
        }

    }
    //removing those trucks that are unable to make the journey from the trucks vector
    for (int i = n.size() - 1; i >= 0; i--)  
    {
        //trucks being removed from the trucks vector
        trucks.erase(trucks.begin() + n[i]);  
        
    }
    
}
//the updating function made in truck.cpp is called here 
//updating with remaining fuel and funds
void TruckDelivery::makeJourney()   
{
    for (int i=0; i<trucks.size();i++)
    {
        trucks[i].updating();
        
    }
}
//the unload function made in truck.cpp is called here on every truck
//information after journey is completed
void TruckDelivery::unloadTrucks() 
{
    
    for (int i=0 ;i<trucks.size();i++)
    {
        trucks[i].unload();
    }

}
