#include "box.hpp"
#include <time.h>
#include <stdlib.h>
using namespace std;
//object 2
Box::Box()
{
    //generating random values for width, height, and length
    //+5 because dimensions range from 5 to 30
    width = rand()%25+5;  
    height = rand()%25+5;
    length = rand()%25+5;

    cout <<"width: "<< width << endl;
    cout <<"length: " << length << endl;
    cout <<"height: " << height << endl;
}
//global
int Box::volume()
{
    //volume of the box
    return width*height*length;  
}