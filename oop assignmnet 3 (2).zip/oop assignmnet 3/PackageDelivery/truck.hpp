#pragma once
#include "box.hpp"
#include <stdlib.h>
#include <time.h>
#include <fstream>
//attributes and member functions
class Truck
{
    string driver;
    int petrol;
    int money;
    int fullMileage;
    int emptyMileage;
    Box box[10];
    public:
    Truck(string,string,string,string,string);
    void load(int numBox);
    void unload();
    float cost();
    bool calculating();
    void updating();
};

