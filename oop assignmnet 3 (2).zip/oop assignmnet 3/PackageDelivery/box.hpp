#pragma once
#include<iostream>
using namespace std;

class Box
{
    int length;
    int width;
    int height;
public:
    Box();

    int volume();
};
